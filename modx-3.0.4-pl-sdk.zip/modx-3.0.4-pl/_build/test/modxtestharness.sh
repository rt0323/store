#!/bin/bash
#
# This script runs the MODX Test Harness.
#

phpunit 