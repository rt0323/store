<?php
namespace MODX\Revolution\Tests\Model\Element;

use MODX\Revolution\modTag;

class modTagElement extends modTag {}
