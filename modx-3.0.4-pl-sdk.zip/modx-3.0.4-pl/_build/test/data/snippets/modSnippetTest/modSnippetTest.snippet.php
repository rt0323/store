<?php
/**
 * @var string $name
 */
return 'Hello, '.$name;