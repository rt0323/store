<?php
/**
 * Action English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['action'] = 'Aktion';
$_lang['action_desc'] = 'Aktionen sind Abstraktionen von MODX-Controllern. Sie können benutzt werden, um eigene Manager-Seiten zu erstellen oder um das Hauptmenü des MODX-Managers umzugestalten.';
$_lang['action_err_ns'] = 'Keine Aktion angegeben!';
$_lang['actions'] = 'Aktionen';
